# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 23:36:53 2019

@author: roshan
"""

# Function definition is here
sum = lambda arg1, arg2: arg1 + arg2

# Now you can call sum as a function
print ("Value of total : ", sum( 10, 20 ))
print ("Value of total : ", sum( 20, 20 ))

# Max number
mx = lambda x, y : x if x > y else y


print(mx(200,100))
