# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 23:36:53 2019

@author: roshan
"""

# Function definition is here
sum = lambda arg1, arg2: arg1 + arg2

# Now you can call sum as a function
print ("Value of total : ", sum( 10, 20 ))
print ("Value of total : ", sum( 20, 20 ))

# Max number
mx = lambda x, y : x if x > y else y

print(mx(10,20))


def square(lst1):
    lst2 = []
    for num in lst1:
        lst2.append(num**2)
    return lst2


n = [4,3,2,1]
print(list(map(lambda x: x**2,n)))
# work same as above function
print([x**2 for x in n])

l = [5,6,1,2]
def over_two(lst1):
    lst2 = [x for x in lst1 if x > 2]
    return lst2

print(over_two(l))

print(list(filter(lambda x:x>2,l )))
