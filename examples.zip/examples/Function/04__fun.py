#!/usr/bin/python

# Function definition is here
def printinfo( name, age ):
   "This prints a passed info into this function"
   print ("Name: ", name)
   print ("Age : ", age)
   

# Now you can call printinfo function
printinfo('Anil',22)
printinfo(  name="miki" , age=50)
