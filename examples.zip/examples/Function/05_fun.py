#!/usr/bin/python

# Function definition is here
# Marking Argument Optional
def printinfo( name, age = 35 ):
   "This prints a passed info into this function"
   print ("Name: ", name)
   print ("Age ", age)
   

# Now you can call printinfo function
printinfo('Anil',22)
printinfo( age=50, name="Anand" )
printinfo( name="Kumar" )
printinfo('Sunil')
