# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 23:12:12 2019

@author: roshan
"""

def build_person(fname,lname):
    """ Returning Dictionary"""
    person = {'first name': fname, 'last name' : lname}
    return person

def print_names(names):
    """ Printing names"""
    for n in names:
        print(n)    
    return sorted(names)

def make_pizza(*toppings):
    """ print the list of toppings that have been requested """
    print('toppings :', toppings)
    #print(type(toppings))

def make_pizza_size(size, *toppings):
    print('toppings :', toppings)
    print('size : ',size)

dict1 = build_person('Anil','Kumar')
print('Return of build_person function : ' , dict1)

name_list = ['Suil', 'Anurag', 'Kapil', 'Nilesh']
sortedname = print_names(name_list)
print('Return of print_names function:', sortedname)

# Passing Arbitrary Number of Arguments
make_pizza('paneer')
make_pizza('green peppers', 'extra chees', 'mushrooms')

make_pizza_size(8,'paneer')
make_pizza_size(16,'green peppers', 'extra chees', 'mushrooms')
