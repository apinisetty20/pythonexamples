#!/usr/bin/python

 
# Function definition is here
def sum( arg1, arg2 ):
   # Add both the parameters and return them."
   add  = arg1 + arg2
   total = add #local total valirable
   print ("Inside the function local total : ", total)
   return add

total = 0
# Now you can call sum function
x = sum( 10, 20 )
print ("Addition " , x)
print ("Outside the function  total : ", total)
