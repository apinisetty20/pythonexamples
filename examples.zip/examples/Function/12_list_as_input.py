# -*- coding: utf-8 -*-
"""
Created on Sat Jun 29 21:43:05 2019

@author: roshan
"""

def check_element_in_list(element, mynamelist):
     return element in mynamelist
         
name=['Anand','Amit','Anurag']
ele='Anand'
value = check_element_in_list(ele,name)
print('Return value is ', value)

if check_element_in_list(ele,name) :
    print('Return valule is ture')
else:
    print('Return value is FALSE')