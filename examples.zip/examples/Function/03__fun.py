def cheese_and_crackers(cheese_count, boxes_of_crackers):
    print ("You have %d cheeses!" % cheese_count)
    print ("You have %d boxes of crackers!" % boxes_of_crackers)
    name = 'Amit'
    print('My name is %s and i have %d cheeses' %(name,cheese_count))
    print ("Man that's enough for a party!")
    print ("Get a blanket.\n")

# main 
print ("We can just give the function numbers directly:")
cheese_and_crackers(20, 30)


print ("OR, we can use variables from our script:")
x = 10
y = 50

cheese_and_crackers(x, y)


print ("We can even do math inside too:")
cheese_and_crackers(10 + 20, 5 + 6)


print ("And we can combine the two, variables and math:")
cheese_and_crackers(100,1000)
