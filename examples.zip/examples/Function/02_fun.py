# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 22:37:59 2019

@author: roshan
"""

def my_display_function(name):
    """ Display a simple greeting """
    print("Hello ", name , "!!")
    

name1 = input('Enter your name:')
my_display_function(name1)
var = 'Sunil'
my_display_function(var)

#Avoiding Argument errors
#my_display_function()

