# Function with return values.
def add(x, y):
    print ("ADDING %d + %d" % (x, y))
    sum = x + y
    return sum

def subtract(x, y):
    print ("SUBTRACTING %d - %d" % (x, y))
    return x - y

def multiply(a, b):
    print ("MULTIPLYING %d * %d" % (a, b))
    return a * b

def divide(a, b):
    print ("DIVIDING %d / %d" % (a, b))
    return a / b


print ("Let's do some math with just functions!")

a = 10
b = 20
total = add(a,b)
print("Total : ", total)

print('Direct fun call : ',add(a,b))

sub = subtract(b, a)
print('Sub : ', sub)

mul = multiply(90, 2)
print ('Mul :', mul)

div = divide(100, 2)
print('Div :', div)


