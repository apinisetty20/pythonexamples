
def someFunction():
    print (a)
    a=100
def fun():
    print(a)
    
a = 10 
someFunction()
fun()