# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 22:36:24 2019

@author: roshan
"""

def my_display_function():
    """ Display a simple greeting """
    print("Hello!")
    print('this is simple display fun')
    
#Calling function
print('Calling Function')
my_display_function()
print('End of example')
