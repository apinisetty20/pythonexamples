# -*- coding: utf-8 -*-
"""
Created on Mon Feb 18 20:31:31 2019

@author: roshan
"""

cars = ['bmw','audi','toyota','tata']

print('without sorting : ', cars)

# Finding index of value
print('Index of tata : ' ,cars.index('tata'))


# Temporarily Sorting a list
print('Temporarily Sorting a list',sorted(cars))

# sorting 
print('Original car list : ', cars)
cars.sort()
print('sorted car list :', cars)

# Reverse Order
cars.reverse()
print('Revers Order :', cars)

# Finding the length of list
length_of_list = len(cars)
print('Length of Cars list:', length_of_list)

# Avoiding index errors change index 0 to 5
print(cars[0])
