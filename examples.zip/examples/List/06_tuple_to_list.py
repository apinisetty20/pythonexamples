# This is a tuple to be converted into list.
aTuple = (123, 'xyz', 'zara', 'abc');
aList = list(aTuple)

print ("List elements : ", aList)
