motorcycles = ['honda','yamaha','suzuki','tvs']

print('Original list:', motorcycles)

# deleting  value in list
del motorcycles[1] 
print('Deleting second element of list : ', motorcycles)

# Removing the element by value in list
motorcycles.remove('tvs')
print('List After remove : ', motorcycles)


del motorcycles
#print(motorcycles)

