motorcycles = ['honda','yamaha','suzuki']

print('Original list:', motorcycles)

# Updating value in list
motorcycles[1] = 'mahindra'
print('Updating second element of list : ', motorcycles)

# Appending the new Item to list
motorcycles.append('tvs')
print('List After Appending : ', motorcycles)

# Inserting the element at position
motorcycles.insert(2,'hero')
print('Inserting new value at position zero : ', motorcycles)
