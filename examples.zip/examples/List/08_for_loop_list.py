name = ["Anand", "Anurag", "Rahul" , "Kapil", "Kumar", ['a','b'] ]

for n in name:
    print ("Hello ", n)
