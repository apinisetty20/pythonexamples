price_list1 = [20000, 80000, 10000]

#max and min method
print ("Max value element : ", max(price_list1)) 
print ("min value element : ", min(price_list1))

price_list2 = [30000, 40000, 50000]

# concatenation
all_price = price_list1 + price_list2
print('New Price List :', all_price)