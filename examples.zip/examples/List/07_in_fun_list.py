
subject = ["CompSci", "Physics", "Maths", "Stats", "CompSci", "Accounting", "Economics", "Management"]

input_val=input("Enter the subject :")

if input_val in subject :
    print ("You can take the subject")
else :
    print ("Not avaliable")


print ("Count : ", subject.count(input_val))

#print ("Index : ", subject.index(input))

#print ("Sorted Function ", sorted(subject))

