# create a mapping of state to abbreviation
states = {
     'MH' : 'Maharashtra',
     'TS' : 'Telangana',
     'AP' : 'Andhra Pradesh',
     'DL' : 'Delhi',
     'MP' :  'Madhya Pradesh'
}

#state capitals
cities = {
             'Maharashtra' : 'Mumbai',
             'Telangana' : 'Hyderabad',
             'Andhra Pradesh' : 'Hyderabad',
             'Delhi' : 'Delhi',
             'Madhya Pradesh' : 'Bhopal'
            }

# do it by using the state then cities 
print ('-' * 10)

print ("Capital of Maharashtra is : ", cities[states['MH']])
print ("Capital of Madhya Pradesh : ", cities[states['MP']])

