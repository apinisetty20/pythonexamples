# create a mapping of state to abbreviation


capitals = {
             'Maharashtra' : 'Mumbai',
             'Telangana' : 'Hyderabad',
             'Andhra Pradesh' : 'Hyderabad',
             'Delhi' : 'Delhi',
             'Madhya Pradesh' : 'Bhopal'
            }

print ("Before : ", capitals)


# Adding 
capitals['Goa'] = 'Panaji'
capitals['Gujarat'] = 'Gandhinagar'
capitals['Karnataka'] = 'Bangalore'

print ("After :", capitals)

# updating / Changing some more cities
print ("Capital of AP was ", capitals['Andhra Pradesh'])
capitals['Andhra Pradesh'] = 'Amravathi'
print ("Capital of AP will be ", capitals['Andhra Pradesh'])
