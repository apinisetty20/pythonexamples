# create a mapping of state to abbreviation
states = {
     'MH' : 'Maharashtra',
     'TS' : 'Telangana',
     'AP' : 'Andhra Pradesh',
     'DL' : 'Delhi',
     'MP' : 'Madhya Pradesh'
}


print (states['MH'])

print (states['TS'])

print (states['DL'])
