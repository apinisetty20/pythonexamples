#!/usr/bin/python

dict1 = {'Name': 'Zara', 'Age': 7}

#copy
dict2 = dict1.copy()
print ("New Dictinary : ", dict2)

tup = ('name', 'age', 'sex')

dict = dict.fromkeys(tup)
print ("New Dictionary :  ", dict)

dict3 = dict.fromkeys(tup, 10)
print ("New Dictionary : ", dict3)


dict1 = {'Name':  {'Name': 'Zara', 'Age': 7}, 'Age': 7}
print(dict1['Name'])