


#state capitals
capitals = {
             'Maharashtra' : 'Mumbai',
             'Telangana' : 'Hyderabad',
             'Andhra Pradesh' : 'Hyderabad',
             'Delhi' : 'Delhi',
             'Madhya Pradesh' : 'Bhopal'
            }

print (" Capital of Maharashtra is " , capitals.get('Maharashtra'))
print (" Capital of Maharashtra is " , capitals.get('Maharashtra',"Not avaliable"))
print (" Capital of Panjab is " , capitals.get('Panjab',"Not avaliable"))

#print('captials of MH Is ',capitals['Panjab'])

if 'Panjab' in capitals.keys():
    print('Present')
else:
    print('Not')