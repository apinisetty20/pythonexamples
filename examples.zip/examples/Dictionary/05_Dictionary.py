#state capitals
capitals = {
             'Maharashtra' : 'Mumbai',
             'Telangana' : 'Hyderabad',
             'Andhra Pradesh' : 'Hyderabad',
             'Delhi' : 'Delhi',
             'Madhya Pradesh' : 'Bhopal'
            }

print ("States  : ")
print (capitals.keys())
k = capitals.keys()
print(k)
print ("Cities  : ")
print (capitals.values())
val = capitals.values()
print('...........',type(val))
print ("Cities  : ")
print (capitals)  #.items() # items are equal to printing complete dict.

#keys in for loop

for keys in capitals.keys():
        #if keys == capitals[keys]:
        print (" Capital of ", keys , " is " , capitals[keys])

print('------ items fun --------------')
for key, values in capitals.items():
    print('Key is', key , ' and value is ', values)