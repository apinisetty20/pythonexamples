#Delete Dictionary Elements

states = {
     'MH' : 'Maharashtra',
     'TS' : 'Telangana',
     'AP' : 'Andhra Pradesh',
     'DL' : 'Delhi',
     'MP' :  'Madhya Pradesh'
}


del states['DL'] # remove entry with key 'Name'

print (states)

states.clear()     # remove all entries in dict

print (states)

del states         # delete entire dictionary



