# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 11:20:48 2019

@author: roshan
"""

# Python Program to count the number of words in a text file.
fname =  input("Enter file name: ") #'read_file.txt'
 
num_words = 0
num_lines = 0
 
f = open(fname, 'r') 
for line in f:
    num_lines += 1
    words = line.split()
    num_words += len(words)
    
print("Number of words:",num_words)
print("Number of lines:", num_lines)
