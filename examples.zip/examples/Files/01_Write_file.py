#!/usr/bin/python

# Open a file
f = open("example_append.txt",'a')
f.write( "Write 7 : Hello, Welcome to My Python Class !!!!\n")
f.write( "Write 8 : Hello, Welcome to My Python Class !!!!\n")
f.write( "Write 9 : Hello, Welcome to My Python Class !!!!\n")
# Close opend file
f.close()
