#!/usr/bin/python

# Open a file
fo = open("example_write.txt", "w+")

fo.write("This is python Class \n We executing Read and wirte script")

print("Pointer position ", fo.tell())

fo.seek(0)
str=fo.read()
print (str)


# Close opend file
fo.close()
