#!/usr/bin/python

# Open a file
fo = open("example_read_writetxt", "w+")

fo.write("This is python Class \n We executing Read and wirte script")


filedata=fo.read()
print ('Filedata is >> ', filedata)


# Close opend file
fo.close()
