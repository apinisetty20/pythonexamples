#!/usr/bin/python
import os

# Rename a file from test1.txt to test2.txt
os.rename( "input2.txt", "input2000.txt" )
