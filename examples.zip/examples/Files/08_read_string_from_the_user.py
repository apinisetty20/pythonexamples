# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 11:26:02 2019

@author: roshan
"""
# Python Program to read a string from the user and appends it into a file.
fname = input("Enter file name: ")
file3=open(fname,"w+")
c=input("Enter string to append: \n");
file3.write("\n")
file3.write(c)
file3.seek(0)
print('Dipslay the file :')
for line in file3:
    print(line)
file3.close()