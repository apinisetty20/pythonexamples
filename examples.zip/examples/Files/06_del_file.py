#!/usr/bin/python
import os

# Delete file 
os.remove("input2000.txt")
