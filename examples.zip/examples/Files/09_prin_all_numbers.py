# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 11:32:39 2019

@author: roshan
"""
#Python Program to print all the numbers present in a text file. 
fname = 'input2.txt '#input("Enter file name: ")
 
f = open(fname, 'r')
print('Digits form a file')
for line in f:
    words = line.split()
    #print(words)
    for i in words:
        if i.isdigit() :
            print(i)
