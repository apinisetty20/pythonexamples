#!/usr/bin/python

# Open a file
f = open("input2.txt",'r')
filedata = f.read(10) # Reads 10 bytes
print ("Read String is : ", filedata)

print('File opend in Mode  : ', f.mode)

print('File Before closing  : ', f.closed)

print('file name is ', f.name)
# Close opend file

if f.closed :
    print('File is closed cant read now......')
else:
    print('Still file is open for read')
    filedata = f.read()
    print(filedata)
    
f.close()
print('File After closing  : ', f.closed)