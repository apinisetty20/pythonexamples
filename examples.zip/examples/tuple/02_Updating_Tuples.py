#!/usr/bin/python

num_tup= (12, 34,56)
alp_tup2 = ('abc', 'xyz')

# Following action is not valid for tuples
#num_tup[0] = 100

# So let's create a new tuple as follows
tup3 = num_tup + alp_tup2
print (tup3)
