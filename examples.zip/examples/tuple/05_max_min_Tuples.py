#!/usr/bin/python

tuple1 = (456, 700, 200)

print ("Max value element : ", max(tuple1))
print ("min value element : ", min(tuple1))
