#!/usr/bin/python

tuple1, tuple2 = (123, 'xyz',12), (456, 'abc')

print ("First tuple length : ", len(tuple1))
print ("Second tuple length : ", len(tuple2))


