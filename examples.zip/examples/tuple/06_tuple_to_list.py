aList = [123, 'xyz', 'zara', 'abc']
aTuple = tuple(aList)

print ("Tuple elements : ", aTuple)

aTuple = (123, 'xyz', 'zara', 'abc')
aList = list(aTuple)
print(aList)

print('executing for loop')
for i in aTuple:
    print(i)