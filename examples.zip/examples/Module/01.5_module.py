import example

total = example.add(10,20)
print('total : ', total)
print(example.pi)



