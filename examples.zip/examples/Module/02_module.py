from example import add

print (add(10,20))

