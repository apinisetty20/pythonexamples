import math
y = 10.5
x = math.ceil(y)
print (x)

x = math.floor(y)

print (x)
