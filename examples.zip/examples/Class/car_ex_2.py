# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 21:59:24 2019

@author: roshan
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 09:08:40 2019

@author: roshan
"""
# Inheritance

class Car():
    """ A simple attempt to represent a car"""
   
    def __init__(self, Make, Model, Year):
        """ Initialize attributes to describe a car. """
        print('Calling Car class __init__ fucntion')
        self.make = Make
        self.model = Model
        self.year = Year
        self.odometer_reading = 0
        
    def get_descriptive_name(self):
        """ Return a neatly formatted dexcriptive name. """
        long_name = str(self.year) + ' ' + self.make + ' ' + self.model
        return long_name.title()
    
    def read_odometer(self):
        """ Print a statment showing the car's milage. """
        print("This car has " + str(self.odometer_reading) + " miles on it.")

    def update_odometer(self, mileage):
        """ Set the odometer reading to the given value """
        if mileage >= self.odometer_reading :
             self.odometer_reading = mileage
        else:
            print("You can't roll back an odometer!!")
            
    def increment_odometer(self, miles):
        self.odometer_reading += miles
        
    def fill_gas_tank(self):
        """ Car Gas tank Size"""
        print("This car has gas tank of size 100 liters.")
        
class ElectricCar(Car):
    """ Represent aspects of a car, specific to electric vehicles."""
    def __init__(self, Make, Model, Year):
        """ Initialize attributes of the parent class"""
        print('Calling ElectricCar class __init__ fucntion')
        super().__init__(Make,Model,Year)
        
#    def describe_battery(self):
#        """ Print battery size """
#        print("This car has ", self.battery.battery_size , ' kwh battery.')

    def fill_gas_tank(self):
        """ Electric cars don't have gas tanks """
        print("ElectricCar : This car doesn't need a gas tank!")
    
    def display_range(self):
        print(self.battery.get_range())


my_tesla = ElectricCar('tesla','model s', 2016)
print(my_tesla.make)
my_tesla.fill_gas_tank()

car_obj = Car('Audi', 'a4',2019)
car_obj.fill_gas_tank()