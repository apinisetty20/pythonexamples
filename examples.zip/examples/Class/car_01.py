# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 09:08:40 2019

@author: roshan
"""

class Car():
    """ A simple attempt to represent a car"""
    
    def __init__(self, Make, Model, Year, price):
        """ Initialize attributes to describe a car. """
        self.make = Make
        self.model = Model
        self.year = Year
        self.__price = price
        
    def get_descriptive_name(self):
        """ Return a neatly formatted dexcriptive name. """
        long_name = str(self.year) + ' ' + self.make + ' ' + self.model + ' ' + \
        str(self.__price)
        print('Long name is', self.year , ' ' , self.make , ' ' , self.model , ' ' , self.__price)
        return long_name.title()

    def __del__(self):
       print('Deleting Obj ')
       
       
my_new_car = Car('audi','a4', 2016,10000)
print(my_new_car.model)
#print(my_new_car.price)
print(my_new_car.get_descriptive_name())

#print(my_new_car.__price)



