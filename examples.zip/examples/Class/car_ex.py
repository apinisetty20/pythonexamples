# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 21:40:03 2019

@author: roshan
"""

class Car():
    """ A simple attempt to represent a car"""
    model = ''
    make = ''
    year = 1990
    
    def dispaly_car_info(self):
        """ Return a neatly formatted dexcriptive name. """
        print('Long name is', self.year , ' ' , self.make , ' ' , self.model )

        
my_new_car = Car()
my_new_car.make = 'audi'
my_new_car.model = 'a4'
my_new_car.year = 2000
my_new_car.dispaly_car_info()
#print(my_new_car.model)
#print(my_new_car.price)
#print(my_new_car.get_descriptive_name())

#print(my_new_car.__price)

