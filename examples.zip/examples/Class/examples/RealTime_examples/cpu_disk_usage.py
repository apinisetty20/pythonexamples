# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 23:34:40 2019

@author: roshan
"""

import psutil

cpu = psutil.cpu_percent()
usage = psutil.disk_usage('c:\\')
mem = psutil.virtual_memory()

print('CPU percent    : ',cpu)
print('C used percent :',usage.percent)
print('Memory usage : ', mem.percent)

if cpu > 80 :
    print('CPU Usage is more than 80%')
else :
    print('CPU Usage is normal')
    
if mem.percent > 80 :
    print('Memory Usage is more than 80%')
else :
    print('Memory Usage is normal')
    
if usage.percent > 80 :
    print('OS Disk Usage is more than 80%')
else :
    print('OS Disk Usage is normal')
    
