# -*- coding: utf-8 -*-
"""
Created on Sat Feb 23 12:02:14 2019

@author: roshan
"""
#source = "C:\Users\roshan\Desktop\Python Classes\External_Modules"
#destination = "C:\Users\roshan\Desktop\Python Classes\External_Modules\backup"
import argparse
from filehandling import FileHandling

parser = argparse.ArgumentParser()

parser.add_argument('-a', '--action', help="Copy, delete or list", required=True)
parser.add_argument('-s', '--source', help="Source the files")
parser.add_argument('-d', '--destination', help="Destination the files")
parser.add_argument('-c', '--cutoff', help="Cut off days")
args = parser.parse_args()

fobj = FileHandling()

if args.action.lower()   == 'copy':
   source = args.source.replace('\\','\\\\')
   dest = args.destination.replace('\\','\\\\')
   fobj.copy_files(source,dest)
elif args.action.lower()   == 'delete':
   source = args.source.replace('\\','\\\\')
   fobj.delete_files_older(source,int(args.cutoff))
elif args.action.lower()   == 'filelist':
   source = args.source.replace('\\','\\\\')
   print(fobj.list_files_older(source,int(args.cutoff)))
else:
   print('Check value passed to action argument')