# -*- coding: utf-8 -*-
"""
Created on Sat Feb 23 11:10:16 2019

@author: roshan
"""

# run by crontab
# removes any files in /tmp/ older than 7 days

import os, shutil, time

class FileHandling():
    """ To manage files """
    def delete_files_older(self,source,cutoff_days):
        """ Delete the files older than cutoff days """
        files = os.listdir(source)
        now = time.time()
        cutoff = now - (cutoff_days * 86400)
        for xfile in files:
            # Checking file
            source_path = os.path.join(source, xfile)
            if os.path.isfile(source_path):
                t = os.stat(source_path)  # Take file states 
                c = t.st_ctime      #  Converting to seconds
                # delete file if older than a week
                if c < cutoff:
                        print("Deleting file : ", xfile)
                        #os.remove(source_path)
                        
    def copy_files(self,source,dest):
        """ Copy the files from source to destination """
        files = os.listdir(source)
        if not os.path.exists(dest) :
           os.makedirs(dest)
        for f in files:
            #print(f)
            if f.endswith(".txt"):
               copy_dest_path = os.path.join(dest, f)
               source_path = os.path.join(source, f)
               shutil.copyfile(source_path, copy_dest_path)
               print(source_path, " File Copied")

    def list_files_older(self,source,cutoff_days):
        """ List the files older than cutoff days """
        files = os.listdir(source)
        now = time.time()
        cutoff = now - (cutoff_days * 86400)
        oldFiles = []
        for xfile in files:
            # Checking file 
            source_path = os.path.join(source, xfile)
            if os.path.isfile(source_path):
                t = os.stat(source_path)  # Take file states 
                c = t.st_ctime      #  Converting to seconds
                # delete file if older than a week
                if c < cutoff:
                    oldFiles.append(xfile)
        return oldFiles

if __name__ == '__main__' :
   spath = "C:\\Users\\roshan\\Desktop\\Python Classes\\External_Modules"
   dpath = "C:\\Users\\roshan\\Desktop\\Python Classes\\External_Modules\\backup"
   fobj = FileHandling()
   fobj.copy_files(spath,dpath)
   print(fobj.list_files_older(spath,1))
   fobj.delete_files_older(spath,1)