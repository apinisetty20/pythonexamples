# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 19:39:05 2019

@author: roshan
"""

import re
import requests 
import smtplib
import os

def deleting_oldfile(filename):
    """ To delete the old file if exist  """
    print("Deleting a file...")
    if os.path.exists(filename):
        os.remove(filename)
    else : 
        print(filename, "File not exists")

def download_file(filename):
    try :
        deleting_oldfile(filename)
        print("Downloading file...")
        url = 'http://feeds.dshield.org/block.txt'
        r = requests.get(url)
        print('URL Connection Status : ', r.status_code)
        f =  open(filename,'wb+')
        f.write(r.content)
        f.close()
    except Exception as e:
        print('Error while downloading a file')
        raise(e)
   #file = open("logfile.txt")

def find_ip(filename):
    try:
       print("Parsing file...")
       f = open(filename,'r')
       email_ip_dict = {}
       for line in f:
           ip = re.findall( r'[0-9]+(?:\.[0-9]+){3}', line )
           if len(ip) > 0 :
              email = re.findall(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", line)
              if email :
                 email_ip_dict[ip[0]] = email[0]
       return email_ip_dict
    except IOError as e:
        print('Error: File not found')
        #raise(e)

def send_email(emails_ips):
    try:
        print("Sending emails...")
        sender = 'from@fromdomain.com'
        for ip in emails_ips.keys():
            message = "Please review  your access to server " + ip
            print(message)
            smtpObj = smtplib.SMTP('localhost')
            smtpObj.sendmail(sender, emails_ips[ip], message)         
            print ("Successfully sent email to ", emails_ips[ip])
    except Exception as e:
        print ("Error: unable to send email")

filename = "logfile.txt"
download_file(filename)
emails_ips = find_ip(filename)
send_email(emails_ips)
