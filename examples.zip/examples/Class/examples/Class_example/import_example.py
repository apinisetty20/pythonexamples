from car import Car, ElectricCar

my_new_car = Car('audi', 'a4',2016)
print(my_new_car.get_descriptive_name())
