# -*- coding: utf-8 -*-
"""
Created on Sat Feb 23 13:17:52 2019

@author: roshan
"""

import csv

person = [['SN', 'Person', 'DOB'],
['1', 'John', '18/1/1997'],
['2', 'Marie','19/2/1998'],
['3', 'Simon','20/3/1999'],
['4', 'Erik', '21/4/2000'],
['5', 'Ana', '22/5/2001']]

#csv.register_dialect('myDialect',
#quoting=csv.QUOTE_ALL,
#skipinitialspace=True, 
csv.register_dialect('myDialect',lineterminator='\r')

f = open('person.csv', 'w')
writer = csv.writer(f,dialect='myDialect')
for row in person:
    writer.writerow(row)

f.close()