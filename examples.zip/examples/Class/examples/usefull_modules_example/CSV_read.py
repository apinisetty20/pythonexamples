# -*- coding: utf-8 -*-
"""
Created on Sat Feb 23 13:25:13 2019

@author: roshan
"""

import csv

csvFile = open('person.csv', 'r')
reader = csv.reader(csvFile)
for row in reader:
    print(row)

csvFile.close()


#Read person.csv file into a dictionary
#csvfile = open("person.csv", 'r')
#reader = csv.DictReader(csvfile)
#for row in reader:
#        print(dict(row))
#
#csvFile.close()

#csvFile = open('person.csv', 'r')
#reader = csv.DictReader(csvFile)
#for row in reader:
#    if row['Person'] == 'Ana':
#        print('DOB of ', row['Person'], ' is ' ,row['DOB'])
#
#csvFile.close()
