# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 23:23:11 2019

@author: roshan
"""

import requests
url='https://ip-ranges.amazonaws.com/ip-ranges.json'
r = requests.get(url)
print('URL Response : ',r.status_code)
return_dict = r.json()

print(type(return_dict))
print(return_dict.keys())

