# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 08:17:18 2019

@author: roshan
"""

NAME='DDDD'

class Dog():
    """ A simple attempt to model a dog. """

    # __init__ method at is a special method python runs automatically
    # Whenever we create a new instance based on the Class
    #
    # Self should be first parameter
    # Self is reference to instance itself
    def __init__(self, dog_name, dog_age):
        """ Initialize name and age attributes """
        self.name = dog_name
        self.age  = dog_age
        
    def sit(self):
        """ Simulate a dog sitting in response to a command """
        print('NAME OF NAME VARIABLE : ', NAME)
        print(self.name.title(), " is now sitting.")
        
    def roll_over(self):
        """ Simulate rolling over in response to a command """
        print(self.name.title(), " rolled over!!")
        

def demo():
    demo_obj = Dog('PPP', 5)
    demo_obj.sit()
    
    
demo()
# Creating Multiple Instanes
my_dog = Dog('tommy', 6)
your_dog = Dog('lucy', 3)
print(NAME)
print('------------------------------')
#Accessing Attributes
print("My dog's name is ", my_dog.name)
print("My dog is ", my_dog.age, " years old.")

# Clling Methods
my_dog.sit()
my_dog.roll_over()

print('------------------------------')
print("Your dog's name is ", your_dog.name)
print("Your dog is ", your_dog.age, " years old.")
your_dog.sit()
your_dog.roll_over()
print('------------------------------')
