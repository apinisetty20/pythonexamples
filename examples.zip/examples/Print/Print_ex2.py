cars = 100
drivers = 30
manager_name= "Mr. Kumar"
manager_ext_no = 101
travels_name = "ABC Transport"
bus_no = 2121
print ("There are", cars)
print ("There are only", drivers, "drivers available.")
print ("Manager : ", manager_name)
print ("Manager Ext. No (phone): ", manager_ext_no)
print ("Travel : ", travels_name , "And Bus no. : ", bus_no)

print ("Travel : %s And Bus no. : %d manager name is %s" % (travels_name, bus_no, manager_name))

