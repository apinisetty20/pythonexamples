#This is my example for print statment 
print ("Hello World!") # This is hello world print statment
print ("Hello Again")
print ("I like typing this.")
print ("This is fun.")
print ('Yay! Printing.')
print ("I much rather you 'not'.")
print ('I "said" do not touch this.')

