print("Mon\t Tue\tWed\tThu\tFri\tSat\tSun")
print("\nJan\nFeb\nMar\nApr\nMay\nJun\nJul\nAug")