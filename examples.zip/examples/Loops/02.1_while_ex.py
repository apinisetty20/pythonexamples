# -*- coding: utf-8 -*-
"""
Created on Mon Feb 18 19:48:29 2019

@author: roshan
"""

password = ''

while password != 'anil123':
    password = input('What is the password?')
    
print('Yes, the password is ' + password + '. You may enter.')
