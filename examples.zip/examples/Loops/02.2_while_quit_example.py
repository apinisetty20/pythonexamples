# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 22:49:40 2019

@author: roshan
"""
message = ''
user_input = ''
print("Tell me something, \n Enter 'quit' to end the program:")
while user_input != 'quit':
    message =   message + "\n" + user_input
    user_input = input()
    
print('-------------------  MESSAGE -------------------------')
print(message)