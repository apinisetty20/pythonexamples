# -*- coding: utf-8 -*-
"""
Created on Sat Mar 30 08:08:08 2019

@author: roshan
"""
number = int(input("Enter the three digit number:"))

originalNum = number
reverseNum=0
while(number > 0):
    reminder = number % 10
    reverseNum  = (reverseNum *10) + reminder
    number = number // 10

if(originalNum  == reverseNum):
    print("orignal and revers number is equal")
else:
    print("orignal and revers number is not equal")

    
