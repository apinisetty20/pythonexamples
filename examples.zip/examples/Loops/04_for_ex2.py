
for num in range(11, 21): #to iterate between 10 to 20
      if num == 15 :
          print('continue the loop')
          continue
      print('num : ', num)

print('bye bye')
