var = 10                    # Second Example
while var > 0:              
   var = var -1
   if 'Anil' == name:
      continue
   print ('Current variable value :', var)
print ("Good bye!")
