

for fruit in 'banana', 'apple',  'mango' :
   print ('Current fruit :', fruit)

for n in 1,2,3,4,5:
   print('number : ', n)

for n in 1,2,3,4,5, 'banana', 'apple',  'mango':
   print('current value : ', n)


print ("Good bye!")
