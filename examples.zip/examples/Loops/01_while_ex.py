count = 0
while (count <= 10):
   print ('The count is:', count)
   count = count + 1

print ("Good bye!")
