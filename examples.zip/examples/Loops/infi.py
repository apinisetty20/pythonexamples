count = 1
while (count > 0):
   print ('The count is:', count)
   count = count + 1
   if count == 100:
       print('time to break the loop')
       break
   

print ("Good bye!")
