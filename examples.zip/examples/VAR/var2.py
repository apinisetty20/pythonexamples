print ("Hello, Python!")
Name="ABC"
Age=20
 print ("NAME: %s" %Name)
print ("Age: %d" %Age)

# Indentaion issue
