# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:30:50 2019

@author: roshan
"""

name = input('what is your name? ')
age = int(input("How old are you? "))
print('datatype of name :', type(name))
print('datatype of age : ', type(age))

