# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:25:46 2019

@author: roshan
"""

message = input("Tell me something, and I will repeat it back to you :")
print(message)