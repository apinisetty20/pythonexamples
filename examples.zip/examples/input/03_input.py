# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:27:39 2019

@author: roshan
"""

# Sometime you want to write a prompt that longer than one line
prompt = "If you tell us who yuo are, we can personalize the message you see."
prompt = prompt + "\n what is your first name? "

name = input(prompt)
print("\n Hello, " , name , "!")
