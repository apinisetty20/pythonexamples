# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 21:07:26 2019

@author: roshan
"""

name='anil'
print(type(name))