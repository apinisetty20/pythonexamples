fname = input("Enter your Fist Name : ")
lname = input("Enter your last name :  ")
print ("First Name : " , fname, "Last Name : ", lname)
