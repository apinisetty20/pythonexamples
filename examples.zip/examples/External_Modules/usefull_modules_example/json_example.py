# -*- coding: utf-8 -*-
"""
Created on Sat Feb 23 12:20:38 2019

@author: roshan
"""

import json

# some JSON:
x =  '{ "name" : "John", "age":30, "city":"New York"}'

print('data type of x ', type(x))
# Converting String to Dictionary:
y = json.loads(x)

print('data type of y ', type(y))
# the result is a Python dictionary:
print(y["age"])


# a Python object (dict):
x = {
  "name": "John",
  "age": 30,
  "city": "New York"
}

# convert into JSON:
y = json.dumps(x)

# the result is a JSON string:
print(y)
print('Type of Y is ', type(y))

