# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 20:47:51 2019

@author: roshan
"""

# imported the requests library 
import requests 

url = 'http://feeds.dshield.org/block.txt'

#url = "https://www.python.org/static/community_logos/python-logo-master-v3-TM.png"
#image_url = 'http://google.com/favicon.ico'  
# URL of the image to be downloaded is defined as image_url 
r = requests.get(url) # create HTTP response object 

print("Connection : ", r.status_code)
print("Content of file", r.content)
#print(r.headers)
  
# send a HTTP request to the server and save 
# the HTTP response in a response object called r 
filename = "logfile.txt"
f =  open("logfile.txt",'wb')
f.write(r.content)
f.close()

