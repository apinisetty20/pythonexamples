# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 22:33:04 2019

@author: roshan
"""

import os

print('OS Version :', os.name)

#The os.environ value is known as a mapping object that returns a dictionary of the 
#user’s environmental variables. You may not know this, but every time you use your 
#computer, some environment variables are set.
os_details = os.environ

#print(os_details)
print('OS Detials', os_details['OS'])
print('Domain :', os_details['USERDOMAIN'])
print('Username :', os_details['USERNAME'])
print('No. of Processors :',os_details['NUMBER_OF_PROCESSORS'])

# another way of using
print(os.environ['USERNAME'])
print(os.environ['NUMBER_OF_PROCESSORS'])

print('Current Dir :',os.getcwd())
#os.chdir("c:\\Users\\roshan\\Documents")
#print('Current Dir :',os.getcwd())

#Create dir
#os.mkdir("test")

#path = r'c:\Users\roshan\Documents\test\abc\xyz\ddd'  
#os.makedirs(path)

# To remove file and dir
#os.remove('test.txt')
#os.rmdir("pytest")

#os.rename("logfile.txt", "pytest.txt")
#The os.startfile() method allows us to “start” a file with its associated program

os.startfile(r'C:\Users\roshan\Desktop\PythonScripts\sampledata.csv')

