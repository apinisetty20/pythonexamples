# -*- coding: utf-8 -*-
"""
Created on Sat Feb 23 13:25:13 2019

@author: roshan
"""

import csv

csvFile = open('person.csv', 'r')
rows = csv.DictReader(csvFile)
for row in rows:
    if row['Person'] == 'Ana':
       print('DOB of ', row['Person'], ' is ' ,row['DOB'])

csvFile.close()




#csvFile = open('person.csv', 'r')
#rows = csv.reader(csvFile)
#for row in rows:
#    print(row)
#
#csvFile.close()


#Read person.csv file into a dictionary
#csvFile = open("person.csv", 'r')
#rows = csv.DictReader(csvFile)
#for row in rows:
#        print(dict(row))
#csvFile.close()
