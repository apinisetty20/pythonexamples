# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 22:54:38 2019

@author: roshan
"""

import shutil, os
files = ['file1.txt', 'file2.txt', 'file3.txt']

def copy_files(source,dest):
    """ Copy the files from source to destination """
    files = os.listdir(source)
    if not os.path.exists(dest) :
       os.makedirs(dest)
    for f in files:
        #print(f)
        if f.endswith(".txt"):
           print(f)
           copy_dest_path = os.path.join(dest, f)
           shutil.copyfile(f, copy_dest_path)
        
spath = "C:\\Users\\roshan\\Desktop\\Python Classes\\External_Modules"
dpath = "C:\\Users\\roshan\\Desktop\\Python Classes\\External_Modules\\backup"
copy_files(spath,dpath)

#print(type(path)) 
#file = os.listdir(os.path.join(r"C:\Users\roshan\Desktop\Python Classes\External_Modules"))
#print(file)
#
#for file in os.listdir("/mydir"):
#    if file.endswith(".txt"):
#        print(os.path.join("/mydir", file))
##def files_backup(source,destination,files)
## Check path of current dir
#dest_path = os.path.join(os.getcwd(), 'backup')
#
## checking folder exists or not
#if not os.path.exists(dest_path) :
#    os.makedirs(dest_path)
#
##coping files
#for f in files:
#    print(f)
#    copy_dest_path = os.path.join(dest_path, f)
#    shutil.copyfile(f, copy_dest_path)
#
## Delete the files
##for f in files:
##    copy_dest_path = os.path.join(dest_path, f)
##    os.remove(copy_dest_path)