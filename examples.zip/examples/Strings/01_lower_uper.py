# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:53:44 2019

@author: roshan
"""

name = 'anil kumar'
city = 'PUNE' 
print(name.upper())
print(city.lower())
length = len(name)
print("Length :", length)