word = "Hello World"

print (word[0])        #get one char of the word
print (word[0:1])       #get one char of the word (same as above)
print (word[0:3])        #get the first three char
print (word[:3])         #get the first three char
print (word[-3:])        #get the last three char
print (word[3:])         #get all but the three first char
print (word[:-3])        #get all but the three last character
