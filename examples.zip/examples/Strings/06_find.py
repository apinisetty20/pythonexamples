# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:49:00 2019

@author: roshan
"""

mystr = "On the other hand, you have different fingers."
print(mystr.find("On"))

mystr = mystr.replace("hand","Leg")
print(mystr)

bol = 'abc' in mystr
print(bol)
