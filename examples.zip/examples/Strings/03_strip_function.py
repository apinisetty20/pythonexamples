# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:03:32 2019

@author: roshan
"""

msg = ' Hellow How are you? '
print('Original message : ', msg)
#print('Original message length :' , len(msg))

# rstrip is for removing the whitespace from the string from right side
msg = msg.rstrip()
print('rstrip function : ',msg)
#print('After rstrip message length :' , len(msg))

# rstrip is for removing the whitespace from the string from right side
msg = msg.lstrip()
print('lstrip function : ',msg)
#print('After lstrip message length :' , len(msg))

message = 'Ok bye bye'
print('rstrip function  message :',message.rstrip())
