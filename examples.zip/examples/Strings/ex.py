# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 21:42:41 2019

@author: roshan
"""

fname = 'Rahul'


fullname = fname * 5
print(fullname)