fname = 'anil'
lname = 'kumar'
fullname = fname + " " + lname
print(fullname.title())
