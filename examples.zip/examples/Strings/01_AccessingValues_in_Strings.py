var1 = 'Hello World!'
var2 = "Python Programming"

print(var1)
print ("var1[0]: ", var1[0])
print ("var1[1:5]: ", var1[5:])

print("Last char", var1[-1])


