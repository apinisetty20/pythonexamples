# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:10:18 2019

@author: roshan
"""


name = 'anil kumar'  
print('Original name : ', name)

print('Title function name : ', name.title())

print("Hello, " , name.title() , " !!")
