# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 20:15:52 2019

@author: roshan
"""

name = 'anil kumar'
age = 22
msg =  "Hello " + name.title() + " Happy " + str(age) + "rd Birthday!"
print("Hello " , name.title() , " Happy " , str(age) , "rd Birthday!")

print("Hello %s Happy %dnd Birthday" %(name,age))

a = 10
b =20
print(a+b)
