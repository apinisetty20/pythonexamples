#!/usr/bin/python

var1 = 'Hello World!'
print (" Before String :- " ,var1)

# Changing the string from 6 character
var1 = var1[:6] + 'Python'
print ("After String :- ", var1)
