#!/usr/bin/python
import re

line = "Cats are smarter than dogs"

matchObj = re.match( r'(Cat.) are ', line)

if matchObj:
   print ("matchObj.group() : ", matchObj.group())
   print ("matchObj.group(1) : ", matchObj.group(1))
 
else:
   print ("No match!!")

f = open("file.txt", "r")
str = f.read(); # Reads 10 bytes
print ("Read String is : ", str)

matchObj = re.match( r'^How', str)

if matchObj:
   print ("matchObj.group() : ", matchObj.group())
   
# Close opend file
f.close()
