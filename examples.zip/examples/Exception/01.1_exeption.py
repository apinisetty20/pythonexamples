# -*- coding: utf-8 -*-
"""
Created on Sat Feb 23 13:40:36 2019

@author: roshan
"""

try:
  fh = open("testfile2.txt", "r")
  fh.read("This is my test file for exception handling!!")
  fh.close()
#except IOError as e :
#  print ("Error: can\'t find file or read data")
#except TypeError as e :
#   print('Handling TypeError')
except Exception as e:
  #print(e.__class__.__name__)
  print(str(e))
  print("Error occured in file read operation")
else:
    print("In case of no error")
    
    
#    print(e.__class__.__name__)
#    print(str(e))
    
    
    
    #except IOError:
#   print ("Error: can\'t find file or read data")
#except TypeError:
#   print('Handling TypeError')
    
#        print("Different Error other than IOError")
