#!/usr/bin/python

try:
   fh = open("testfile12321.txt", "r")
   fh.write("This is my test file for exception handling!!")
   print('Last statment of try block')
except IOError:
   print ("Error: can\'t find file or read data")

finally:
      print ("Going to close the file")
      fh.close()