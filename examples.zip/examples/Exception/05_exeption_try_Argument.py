#!/usr/bin/python

# Define a function here.
def temp_convert(var):
   try:
      print('Tyr block 1')
      
      try :
          print("Try block 2")
          return int(var)
      except Exception :
          print("Error in Try 2")
   except ValueError as Argument:
      print ("The argument does not contain numbers\n", Argument)

# Call above function here.
temp_convert("xyz")
