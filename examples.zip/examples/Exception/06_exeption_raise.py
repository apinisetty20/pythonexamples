#!/usr/bin/python

try:
    a = int(input("Enter a positive integer: "))
    if a == 0:
         raise ValueError("That is ZERO number!")
    elif a < 0 :
         raise ValueError("That is not a positive number!")
    elif a > 100 :
         raise Exception('Value Greater than 100')
except ValueError as ve:
     print('Value Error Occured')
     print(ve)
except Exception as ve:
     print(ve)
     print('Exception Occured')
