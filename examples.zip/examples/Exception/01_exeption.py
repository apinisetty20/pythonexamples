# Assuming we want to ask the user to enter an integer number. 
# If we use a raw_input(), the input will be a string, 
# which we have to cast into an integer. 
# If the input has not been a valid integer, 
# we will generate (raise) a ValueError. 


#while True:
try:
        n = input("Please enter an integer: ")
        n = int(n)
        f = open('ddddd')
#        break
except ValueError as e:
        #pass
        print(e)
        print("No valid integer! Please try again ...")
except IOError:
       print('File not found to read')
        
print ("Great, you successfully entered an integer!")
