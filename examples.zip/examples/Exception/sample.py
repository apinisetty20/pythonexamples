# -*- coding: utf-8 -*-
"""
Created on Thu Apr 18 07:36:28 2019

@author: roshan
"""
n = input("Please enter an integer: ")
n = int(n)