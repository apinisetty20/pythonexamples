name = input('Enter your name :')
age  = int(input('Enter your age:'))

if age > 17:
  print("Welcome")
  print("Hello Mr. " , name , "eligible for voting")

print("End of program")