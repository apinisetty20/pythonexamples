# Program checks if the number is positive or negative
# And displays an appropriate message



# Try these two variations as well. 
# num = -5
# num = 0
# num = 3

num = int(input("Enter the number :"))

if num == 0:
    print("Its Zero Number")
elif num > 0:
    print("Its Positive number")
else:
    print("Its Negative number")