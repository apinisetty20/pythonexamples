
var = 100

if ( var  == 100 ) : print ("Value of expression is 100")

print ("Good bye!")
