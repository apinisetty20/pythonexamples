# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 22:37:12 2019

@author: roshan
"""

name = input("Enter student name :")
percentage = int(input("Enter student percentage :"))

if percentage >= 65:
    print("Passing grade of:")
    if percentage >= 90:
        print("Your Grade is A")
    elif percentage >=80:
        print("Your Grade is B")
    elif percentage >=70:
        print("Your Grade is C")
    elif percentage >= 65:
        print("Your Grade is D")
else:
    print("Failing grade")

print('bye bye')