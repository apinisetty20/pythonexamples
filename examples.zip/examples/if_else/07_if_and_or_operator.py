# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 22:47:35 2019

@author: roshan
"""

name = "Rick"
age = 23
if name == "John" and age == 23:
    print("Your name is John, and you are also 23 years old.")

if name == "John" or name == "Rick":
    print("Your name is either John or Rick.")